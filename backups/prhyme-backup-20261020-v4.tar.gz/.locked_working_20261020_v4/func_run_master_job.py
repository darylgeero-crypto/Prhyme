# Locked working version 2026-10-19
# Function: run_master_job (lines 1246-1654)

def run_master_job(job_id, src_path, genre, bpm_opt, seed, title, mopts=None):
    def prog(p, msg):
        set_job(job_id, progress=p, message=msg)
    try:
        mopts = mopts or {}
        # Temp job folder: copy the source in, work from the copy.
        # The original upload is never touched or deleted.
        tdir = _temp_master_dir(job_id)
        os.makedirs(tdir, exist_ok=True)
        # Save mopts for crash recovery (resume needs the original options)
        try:
            _mopts_save = dict(mopts or {})
            _mopts_save["genre"] = genre
            _mopts_save["title"] = title
            _mopts_save["bpm"] = bpm_opt
            _mopts_save["seed"] = seed
            with open(os.path.join(tdir, "mopts.json"), "w") as _mf:
                json.dump(_mopts_save, _mf)
        except Exception:
            pass
        # No accumulation: a new master job clears older master temp dirs.
        try:
            for _jd in os.listdir(TEMP_MASTERS_DIR):
                if _jd != job_id[:8]:
                    temp_master_cleanup(_jd)
        except OSError:
            pass
        _sext = os.path.splitext(src_path)[1].lower() or ".wav"
        temp_src = os.path.join(tdir, "source" + _sext)
        shutil.copy2(src_path, temp_src)
        src_path = temp_src
        chain = mopts.get("chain", "Streaming")
        # Daryl's fast path: large 'keep original' files use 4-min sections
        # (never loads full file into RAM). Sequential, 45s chunks inside.
        _is_keep = mopts.get("beat_source", "generate") == "keep"
        if _is_keep:
            try:
                import subprocess
                _r = subprocess.run(
                    ["ffprobe", "-v", "error", "-show_entries", "format=duration",
                     "-of", "default=noprint_wrappers=1:nokey=1", src_path],
                    capture_output=True, text=True, timeout=15)
                _dur = float(_r.stdout.strip())
            except Exception:
                _dur = 0
            if _dur > 4 * 60:  # >4 minutes: use sectioned mastering
                prog(3, f"Large file ({_dur/60:.1f} min) — using 4-min sections…")
                pcm16, report = master_large_sections(
                    src_path, masterfx, chain, mopts, prog, SR,
                    checkpoint_dir=tdir, job_id=job_id)
                # Write output (same as normal path)
                safe = safe_name(title, "djrill-master")
                base = f"{safe}_prhymemaster"
                _fmt = mopts.get("output_format", "mp3")
                if _fmt not in ("mp3", "wav", "flac", "ogg", "m4a", "opus"):
                    _fmt = "mp3"
                tmp_wav = os.path.join(tdir, base + ".tmp.wav")
                prog(86, "Writing master…")
                wav_write(tmp_wav, SR, pcm16)
                if _fmt == "wav":
                    final_path = os.path.join(tdir, base + ".wav")
                    os.replace(tmp_wav, final_path)
                elif _fmt == "flac":
                    final_path = os.path.join(tdir, base + ".flac")
                    prog(92, "Encoding FLAC…")
                    C.convert_file(tmp_wav, final_path)
                    os.remove(tmp_wav)
                elif _fmt == "ogg":
                    final_path = os.path.join(tdir, base + ".ogg")
                    prog(92, "Encoding OGG…")
                    C.convert_file(tmp_wav, final_path)
                    os.remove(tmp_wav)
                elif _fmt == "m4a":
                    final_path = os.path.join(tdir, base + ".m4a")
                    prog(92, "Encoding M4A…")
                    C.convert_file(tmp_wav, final_path)
                    os.remove(tmp_wav)
                elif _fmt == "opus":
                    final_path = os.path.join(tdir, base + ".opus")
                    prog(92, "Encoding Opus…")
                    C.convert_file(tmp_wav, final_path)
                    os.remove(tmp_wav)
                else:
                    final_path = os.path.join(tdir, base + ".mp3")
                    prog(92, "Encoding MP3…")
                    encode_mp3(tmp_wav, final_path)
                    os.remove(tmp_wav)
                prog(96, "Building A/B previews…")
                ab_src = None
                ab_mst = None
                if mopts.get("ab_compare", "1") == "1":
                    tmpdir_ab = os.path.join(OUTPUT_DIR, "temp_ab")
                    os.makedirs(tmpdir_ab, exist_ok=True)
                    ab_src = _ab_excerpt(src_path, tmpdir_ab, f"{job_id[:8]}_ab-source.mp3")
                    ab_mst = _ab_excerpt(final_path, tmpdir_ab, f"{job_id[:8]}_ab-master.mp3")
                set_job(job_id, status="done", progress=100,
                        message=f"Track Prhymed! — {report['lufs']} LUFS, "
                                f"{report['true_peak_dbtp']} dBTP",
                        result={"file": os.path.basename(final_path),
                                "format": _fmt,
                                "temp": True,
                                "job_id": job_id,
                                "lufs": report["lufs"],
                                "dbtp": report["true_peak_dbtp"],
                                "bpm": 0,
                                "duration": report["duration_s"],
                                "fx_applied": [],
                                "report": report,
                                "ab_source": ab_src,
                                "ab_master": ab_mst})
                return
        prog(3, "Loading your recording…")
        _, vocal = M.load_audio(src_path)
        # 140. corrupt-audio guard: reject silent / NaN / broken files
        if vocal.size == 0 or not np.all(np.isfinite(vocal)):
            raise ValueError("Recording is unreadable (corrupt audio data)")
        if np.max(np.abs(vocal)) < 1e-6:
            raise ValueError("Recording is silent — nothing to master")
        v_dur = vocal.shape[0] / SR

        bpm = bpm_opt or M.detect_bpm(vocal.mean(axis=1), SR) or 90.0
        prog(8, f"Tempo locked: {bpm:.1f} BPM")
        _keep_original = mopts.get("beat_source", "generate") == "keep"
        _beat_style = mopts.get("beat_style", "match")
        _beat_genre = genre
        if not _keep_original and _beat_style == "different":
            _beat_genre = mopts.get("new_genre") or genre
        if not _keep_original:
            # New backing beat: isolate vocals first so the original
            # instrumental does not bleed into the mix under the new beat.
            prog(9, "Separating vocals from original…")
            _sep_wav = os.path.join(tdir, "sep_input.wav")
            _pcm = np.clip(vocal, -1.0, 1.0)
            wav_write(_sep_wav,
                      SR, (_pcm * 32767).astype(np.int16))
            del _pcm
            _voc, _orig_inst = vocalfx.separate_track(
                _sep_wav,
                progress=lambda f: prog(
                    9 + int(f * 0.05),
                    f"Separating vocals… {int(f)}%"))
            try:
                os.remove(_sep_wav)
            except OSError:
                pass
            vocal = _voc
            del _voc
            v_dur = vocal.shape[0] / SR
        bar_dur = 60.0 / bpm * 4
        intro = bar_dur  # 1 intro bar
        n_bars = int(np.ceil((intro + v_dur + 2 * bar_dur) / bar_dur))

        _lite = lite_mode()
        # Memory guard: vocal + beat + mix buffers.
        # Lite mode uses the lightweight renderer (fewer numpy temporaries).
        _nbuf = 2 if _keep_original else 4
        check_audio_budget(vocal.shape[0] * _nbuf, channels=2,
                           copies=4, label="master", headroom_mb=80)
        if _keep_original:
            prog(10, "Keeping original audio (no new beat)...")
            beat = None
        elif _lite:
            # Lite: phone-safe lightbeat renderer instead of the V68 engine,
            # capped at 32 bars then tiled to cover long vocals.
            prog(10, f"Rendering backing beat (lite)…")
            _lb_bars = min(n_bars, 32)
            beat = lightbeat.generate_beat(_beat_genre, float(bpm), _lb_bars, seed,
                progress_cb=lambda f, m: prog(10 + int(40 * f), m or f"Beat {int(f*_lb_bars)}/{_lb_bars}…"))
            _need = int(np.ceil((intro + v_dur + 2 * bar_dur) * SR))
            if beat.shape[0] < _need:
                _reps = int(np.ceil(_need / beat.shape[0]))
                beat = np.tile(beat, (_reps, 1))[:_need]
        else:
            eng = get_engine()
            prog(10, f"Rendering {n_bars} bars of {_beat_genre} beat…")
            beat = render_beat_progress(
                eng, _beat_genre, bpm, n_bars, seed,
                lambda b, n: prog(10 + int(45 * b / n), f"Beat bar {b}/{n}…"))

        # Structure match: the new beat follows the OG's song structure.
        # Per-bar energy of the original instrumental -> per-bar gain on the
        # new beat, so drops/breaks/hooks land where the original had them.
        if not _keep_original and beat is not None:
            try:
                prog(57, "Matching song structure…")
                beat = _match_beat_structure(beat, _orig_inst, bar_dur,
                                             intro)
            except Exception as _se:
                print(f"structure match skipped: {_se}")
            del _orig_inst
        # Generated beat persists in the temp beats ring (last 5) even if
        # this master is never downloaded.
        if not _keep_original and beat is not None:
            try:
                _bpeak = float(np.max(np.abs(beat)))
                _bnorm = beat * (0.89 / _bpeak) if _bpeak > 0 else beat
                _bpcm = (np.clip(_bnorm, -1.0, 1.0) * 32767).astype(np.int16)
                _bbase = f"{job_id[:8]}_djrill-beat_{_beat_genre}_{int(round(float(bpm)))}bpm"
                os.makedirs(TEMP_BEATS_DIR, exist_ok=True)
                _bwav = os.path.join(TEMP_BEATS_DIR, _bbase + ".wav")
                wav_write(_bwav, SR, _bpcm)
                temp_beats_register(job_id, _bbase, {"wav": _bbase + ".wav"},
                                    genre, float(bpm),
                                    round(beat.shape[0] / SR, 1))
            except Exception as _be:
                print(f"beat ring save failed: {_be}")
        prog(58, "Polishing vocal (EQ + gentle compression)…")
        vp = M.polish_vocal(vocal)

        # ✨ Vocal polish: gentle denoise + presence + de-ess (never deletes)
        if mopts.get("vocal_polish", True):
            prog(60, "✨ Vocal polish — clarity…")
            vp_pol = vocalfix.polish_vocal_clarity(vp)
            ok_nd, _ = vocalfix.verify_no_dropouts(vp, vp_pol)
            if ok_nd:
                vp = vp_pol
            # else: keep M.polish_vocal output (never risk a deletion)

        # 🎯 Timing fix: subtle nudge toward beat grid (never cuts words)
        if mopts.get("timing_fix", True):
            prog(62, "🎯 Timing fix — nudging to grid…")
            vp_t, tinfo = vocalfix.fix_vocal_timing(vp, bpm=float(bpm))
            ok_nd, _ = vocalfix.verify_no_dropouts(vp, vp_t)
            if ok_nd:
                vp = vp_t
                if tinfo.get("corrected"):
                    prog(64, f"Timing nudged ({tinfo.get('nudged',0)} spots, "
                             f"max {tinfo.get('max_shift_ms',0):.0f} ms)")
            # else: keep un-timed version (never risk a deletion)

        # 🎛 Creative FX on the vocal (radio/vinyl/TV/filters/echo).
        # Envelope-preserving DSP only — words stay intact.
        fx_applied = []
        if mopts.get("fx_target", "vocal") == "vocal":
            prog(64, "🎛 Creative FX — vocal…")
            vp_fx, fx_applied = trackfx.apply_vocal_fx(
                vp, mopts, bpm=float(bpm))
            ok_nd, _ = vocalfix.verify_no_dropouts(vp, vp_fx)
            if not ok_nd:
                vp_fx, fx_applied = vp, []  # never risk a deletion
        else:
            vp_fx = vp

        prog(65, "Mixing — balanced vocal/instrumental…")
        boost_db = float(mopts.get("vocal_boost_db", 1.5))
        need = int(intro + vocal.shape[0] + 1 * SR)
        if _keep_original:
            # Keep original: use polished audio directly, no beat mixing
            mix = vp_fx.copy()
            s0 = 0
        else:
            mix = np.zeros((max(need, beat.shape[0]), 2))
            mix[:beat.shape[0]] += beat * 0.9
            s0 = int(intro * SR)
            mix[s0:s0 + vp_fx.shape[0]] += vp_fx * 10 ** (boost_db / 20.0)
            end = min(mix.shape[0], s0 + vp_fx.shape[0] + int(2 * SR))
            mix = mix[:end]
        # configurable fades
        mix = masterfx.apply_fades(
            mix, float(mopts.get("fade_in", 0.5)),
            float(mopts.get("fade_out", 3.0)))
        # 🎛 Creative FX on the full mix instead of the vocal
        if mopts.get("fx_target", "vocal") == "mix":
            prog(78, "🎛 Creative FX — full mix…")
            mix, fx_applied = trackfx.apply_vocal_fx(
                mix, mopts, bpm=float(bpm))

        # lyric-integrity gate before mastering
        ok_vox, vox_corr = M.verify_vocal_integrity(vp_fx, mix, s0)
        if not ok_vox:
            print(f"WARNING: Vocal integrity low (corr={vox_corr:.2f}) -- continuing")

        prog(80, "Mastering…")
        # Free vocal/beat buffers now that mix is built (low-RAM: dead
        # from here on; master_chunked only needs mix).
        import gc as _gc
        try:
            del vocal
        except NameError:
            pass
        try:
            del beat
        except NameError:
            pass
        try:
            del vp
        except NameError:
            pass
        try:
            del vp_fx
        except NameError:
            pass
        _gc.collect()
        ref_path = mopts.get("reference_path")
        if ref_path and not _lite:
            # Lite skips reference spectrum matching (heavy FFT analysis).
            mix, ref_lufs, deltas = masterfx.match_reference_spectrum(
                mix, ref_path)
            mopts = dict(mopts, target_lufs=ref_lufs)
        # For large mixes (>3 min), spill to disk first so master_chunked
        # can stream instead of holding the full array in RAM.
        _mix_arg = mix
        _spill_wav = None
        try:
            import numpy as _np
            _mix_len = mix.shape[0] if hasattr(mix, "shape") else 0
            if _mix_len > 3 * 60 * SR:  # >3 minutes
                import tempfile, os as _os
                from scipy.io.wavfile import write as _wav_write
                _spill_wav = _os.path.join(tdir, "_mix_spill.wav")
                # Normalize to int16 for disk
                _m = mix
                if _m.dtype != _np.int16:
                    _peak = _np.abs(_m).max()
                    if _peak > 0:
                        _m = (_m / _peak * 32767).astype(_np.int16)
                    else:
                        _m = _m.astype(_np.int16)
                _wav_write(_spill_wav, SR, _m)
                del _m
                _mix_arg = _spill_wav
                del mix  # Free the RAM
                import gc as _gc2
                _gc2.collect()
        except Exception as _e:
            print(f"spill failed: {_e}, using in-RAM")
            _mix_arg = mix
        pcm16, report = master_chunked(
            _mix_arg, masterfx, chain, mopts, prog, SR)
        # Cleanup spill file
        try:
            if _spill_wav and os.path.exists(_spill_wav):
                os.remove(_spill_wav)
        except Exception:
            pass

        safe = safe_name(title, "djrill-master")
        base = f"{safe}_prhymemaster"
        _fmt = mopts.get("output_format", "mp3")
        if _fmt not in ("mp3", "wav", "flac", "ogg", "m4a", "opus"):
            _fmt = "mp3"
        # Exactly one final format, written to the temp job folder.
        # 141. atomic writes: tmp + rename so partial files never surface
        tmp_wav = os.path.join(tdir, base + ".tmp.wav")
        prog(86, "Writing master…")
        wav_write(tmp_wav, SR, pcm16)
        if _fmt == "wav":
            final_path = os.path.join(tdir, base + ".wav")
            os.replace(tmp_wav, final_path)
        elif _fmt == "flac":
            final_path = os.path.join(tdir, base + ".flac")
            prog(92, "Encoding FLAC…")
            C.convert_file(tmp_wav, final_path)
            os.remove(tmp_wav)
        elif _fmt == "ogg":
            final_path = os.path.join(tdir, base + ".ogg")
            prog(92, "Encoding OGG…")
            C.convert_file(tmp_wav, final_path)
            os.remove(tmp_wav)
        elif _fmt == "m4a":
            final_path = os.path.join(tdir, base + ".m4a")
            prog(92, "Encoding M4A…")
            C.convert_file(tmp_wav, final_path)
            os.remove(tmp_wav)
        elif _fmt == "opus":
            final_path = os.path.join(tdir, base + ".opus")
            prog(92, "Encoding Opus…")
            C.convert_file(tmp_wav, final_path)
            os.remove(tmp_wav)
        else:
            final_path = os.path.join(tdir, base + ".mp3")
            prog(92, "Encoding MP3…")
            encode_mp3(tmp_wav, final_path)
            os.remove(tmp_wav)
        prog(96, "Building A/B previews…")

        # Generate A/B excerpts BEFORE marking done: the frontend renders the
        # result once on status=done and never re-polls, so excerpts made after
        # done would never appear (race condition fixed 2026-10-16).
        ab_src = None
        ab_mst = None
        if mopts.get("ab_compare", "1") == "1":
            tmpdir = os.path.join(OUTPUT_DIR, "temp_ab")
            os.makedirs(tmpdir, exist_ok=True)
            ab_src = _ab_excerpt(src_path, tmpdir, f"{job_id[:8]}_ab-source.mp3")
            ab_mst = _ab_excerpt(final_path, tmpdir, f"{job_id[:8]}_ab-master.mp3")

        set_job(job_id, status="done", progress=100,
                message=f"Track Prhymed! — {report['lufs']} LUFS, "
                        f"{report['true_peak_dbtp']} dBTP",
                result={"file": os.path.basename(final_path),
                        "format": _fmt,
                        "temp": True,
                        "job_id": job_id,
                        "lufs": report["lufs"],
                        "dbtp": report["true_peak_dbtp"],
                        "bpm": round(float(bpm), 1),
                        "duration": report["duration_s"],
                        "fx_applied": fx_applied,
                        "report": report,
                        # 25. A/B compare: optional 30s excerpts (stored in temp)
                        "ab_source": ab_src,
                        "ab_master": ab_mst})
    except Exception as e:
        set_job(job_id, status="error", progress=0, message=f"Error: {e}")
        try:
            temp_master_cleanup(job_id)
        except Exception:
            pass
