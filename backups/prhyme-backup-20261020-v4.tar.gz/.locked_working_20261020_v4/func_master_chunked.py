# Locked working version 2026-10-19
# Function: master_chunked (lines 227-372)

def master_chunked(mix, masterfx, chain, mopts, prog, SR=44100):
    """Master long audio in 45s chunks with 2s overlap crossfades.
    STREAMING: takes file path OR numpy array. If path, streams from disk
    using memory-mapping — never loads full file into RAM. Phone-safe for
    20+ minute tracks."""
    import gc, os
    import numpy as np
    CHUNK_S = 45
    OVERLAP_S = 2
    chunk_n = int(CHUNK_S * SR)
    overlap_n = int(OVERLAP_S * SR)

    # Streaming mode: memory-map the file from disk
    is_path = isinstance(mix, str)
    mmap = None
    if is_path:
        # Get info without loading
        from scipy.io.wavfile import read as wav_read
        # Use memmap for WAV files
        if mix.lower().endswith(".wav"):
            import wave
            with wave.open(mix, "rb") as w:
                n_frames = w.getnframes()
                n_ch = w.getnchannels()
                sampwidth = w.getsampwidth()
                framerate = w.getframerate()
            # Memory-map the raw PCM data (skip 44-byte header for standard WAV)
            # Fallback: load in chunks via soundfile if available
            try:
                import soundfile as sf
                info = sf.info(mix)
                total = info.frames
                n_ch = info.channels
                use_sf = True
            except ImportError:
                use_sf = False
                # Fallback: load fully (old behavior) if no soundfile.
                # scipy returns int16 — convert to float [-1, 1] for the
                # mastering chain (master_with_options expects float).
                sr, mix = wav_read(mix)
                if mix.dtype == np.int16:
                    mix = mix.astype(np.float32) / 32768.0
                elif mix.dtype == np.int32:
                    mix = mix.astype(np.float32) / 2147483648.0
                elif mix.dtype == np.uint8:
                    mix = (mix.astype(np.float32) - 128) / 128.0
                total = mix.shape[0]
                n_ch = mix.shape[1] if mix.ndim > 1 else 1
        else:
            # Non-WAV: try soundfile, else load fully
            try:
                import soundfile as sf
                info = sf.info(mix)
                total = info.frames
                n_ch = info.channels
                use_sf = True
            except ImportError:
                use_sf = False
                raise ValueError("soundfile required for streaming non-WAV")
    else:
        # Old behavior: numpy array already in RAM.
        # Ensure float [-1, 1] for the mastering chain.
        use_sf = False
        if mix.dtype == np.int16:
            mix = mix.astype(np.float32) / 32768.0
        elif mix.dtype == np.int32:
            mix = mix.astype(np.float32) / 2147483648.0
        elif mix.dtype == np.uint8:
            mix = (mix.astype(np.float32) - 128) / 128.0
        total = mix.shape[0]
        n_ch = mix.shape[1] if mix.ndim > 1 else 1

    def _get_chunk(start, end):
        """Get audio chunk [start:end] without loading full file."""
        if not is_path or not use_sf:
            return mix[start:end]
        import soundfile as sf
        data, _ = sf.read(mix, start=start, stop=end, always_2d=True)
        return data

    def _master_one(chunk):
        return masterfx.master_with_options(
            chunk, chain_name=chain,
            target_lufs=mopts.get("target_lufs"),
            ceiling_db=float(mopts.get("ceiling_db", -1.0)),
            dither=bool(mopts.get("dither", True)),
            deess=float(mopts.get("deess", 0.0)),
            multiband=bool(mopts.get("multiband", False)))

    if total <= chunk_n:
        chunk = _get_chunk(0, total)
        return _master_one(chunk)

    n_chunks = int(np.ceil(total / chunk_n))
    prog(80, f"Mastering in {n_chunks} chunks (streaming from disk)...")

    import tempfile
    spill = tempfile.mkdtemp(prefix="mchunks_")
    chunk_files = []
    last_report = None
    try:
        for i in range(n_chunks):
            start = max(0, i * chunk_n - overlap_n if i > 0 else 0)
            end = min(total, (i + 1) * chunk_n + (overlap_n if i < n_chunks - 1 else 0))
            chunk = _get_chunk(start, end)
            # Free the chunk reference after use
            prog(80 + int(5 * i / n_chunks), f"Mastering chunk {i+1}/{n_chunks}...")
            pcm16, report = _master_one(chunk)
            last_report = report
            del chunk
            gc.collect()
            # Spill to disk immediately
            cf = os.path.join(spill, f"chunk_{i:04d}.npy")
            np.save(cf, pcm16)
            chunk_files.append((start, end, cf))
            del pcm16
            gc.collect()

        # Splice chunks from disk with crossfades
        prog(86, "Splicing chunks...")
        # Load first chunk to get shape
        first = np.load(chunk_files[0][2])
        n_ch_out = first.shape[1] if first.ndim > 1 else 1
        del first
        # Build output incrementally
        result_parts = []
        for idx, (start, end, cf) in enumerate(chunk_files):
            data = np.load(cf)
            # Trim overlap (except first/last)
            if idx > 0:
                data = data[overlap_n:]
            if idx < len(chunk_files) - 1:
                data = data[:-overlap_n] if overlap_n > 0 else data
            result_parts.append(data)
            os.remove(cf)  # Free disk immediately
        import shutil
        shutil.rmtree(spill, ignore_errors=True)
        # Concatenate
        result = np.concatenate(result_parts, axis=0)
        del result_parts
        gc.collect()
        return result, last_report
    except Exception:
        import shutil
        shutil.rmtree(spill, ignore_errors=True)
        raise
