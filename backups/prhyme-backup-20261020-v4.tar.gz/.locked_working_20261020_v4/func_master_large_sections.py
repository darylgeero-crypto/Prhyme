# Locked working version 2026-10-19
# Function: master_large_sections (lines 1070-1242)

def master_large_sections(src_path, masterfx, chain, mopts, prog, SR=44100, section_min=4, checkpoint_dir=None, job_id=None):
    """Daryl's two-level chunking for large 'keep original' files.
    1. Split into 4-min sections via ffmpeg (disk only, zero RAM).
    2. Master each 4-min section sequentially using 45s chunks (master_chunked).
    3. Stitch sections with 2s crossfades.
    Returns (pcm16, report). Never loads the full file into RAM.

    If checkpoint_dir is given, mastered sections are saved to disk there
    and a checkpoint.json tracks progress — a crash can resume from the
    last completed section instead of starting over.
    """
    import subprocess, tempfile, shutil
    import numpy as np

    SECTION_S = section_min * 60
    XFADE_S = 2
    xfade_n = int(XFADE_S * SR)

    # Checkpoint setup
    ckpt_path = os.path.join(checkpoint_dir, "checkpoint.json") if checkpoint_dir else None
    sections_done = set()
    if ckpt_path and os.path.exists(ckpt_path):
        try:
            with open(ckpt_path) as f:
                ck = json.load(f)
            sections_done = set(ck.get("sections_done", []))
            if sections_done:
                prog(5, f"Resuming — {len(sections_done)} sections already done…")
        except Exception:
            pass

    def _save_ckpt(total, done_list, phase):
        if not ckpt_path:
            return
        try:
            with open(ckpt_path + ".tmp", "w") as f:
                json.dump({"job_id": job_id, "phase": phase,
                           "sections_total": total,
                           "sections_done": sorted(done_list)}, f)
            os.replace(ckpt_path + ".tmp", ckpt_path)
        except Exception:
            pass

    # Get duration via ffprobe (no RAM)
    try:
        r = subprocess.run(
            ["ffprobe", "-v", "error", "-show_entries", "format=duration",
             "-of", "default=noprint_wrappers=1:nokey=1", src_path],
            capture_output=True, text=True, timeout=15)
        duration = float(r.stdout.strip())
    except Exception:
        # Fallback: estimate from file size (MP3 ~128kbps)
        try:
            sz = os.path.getsize(src_path)
            duration = sz / 16000.0
        except Exception:
            duration = 0

    if duration <= SECTION_S:
        # Not large — use normal path
        return master_chunked(src_path, masterfx, chain, mopts, prog, SR)

    n_sections = int(np.ceil(duration / SECTION_S))
    prog(5, f"Large file ({duration/60:.1f} min) — splitting into {n_sections} sections…")

    tmpdir = tempfile.mkdtemp(prefix="msect_")
    section_files = []
    try:
        # Split via ffmpeg segment (disk only).
        # Output WAV (not MP3): master_chunked can stream WAV without the
        # optional 'soundfile' package, which isn't guaranteed on Render/phone.
        seg_pat = os.path.join(tmpdir, "sect_%03d.wav")
        subprocess.run(
            ["ffmpeg", "-y", "-i", src_path,
             "-f", "segment", "-segment_time", str(SECTION_S),
             "-c:a", "pcm_s16le", "-ar", str(SR), "-ac", "2", seg_pat],
            capture_output=True, timeout=180)

        # Collect segments
        for i in range(n_sections):
            fp = os.path.join(tmpdir, f"sect_{i:03d}.wav")
            if os.path.exists(fp) and os.path.getsize(fp) > 1024:
                section_files.append(fp)

        if not section_files:
            raise ValueError("Section split produced no files")

        # Master each section sequentially (45s chunks inside)
        # With checkpointing: save each mastered section to disk, skip done ones
        mastered_parts = []
        last_report = None
        for idx, sf in enumerate(section_files):
            # Check if this section was already mastered (resume)
            sect_ckpt = None
            if checkpoint_dir:
                sect_ckpt = os.path.join(checkpoint_dir, f"mastered_sect_{idx:03d}.wav")
                if idx in sections_done and os.path.exists(sect_ckpt):
                    prog(10 + int(70 * idx / len(section_files)),
                         f"Section {idx+1}/{len(section_files)} — already done, skipping…")
                    # Load from disk
                    try:
                        import scipy.io.wavfile as _wv
                        _sr, _pcm = _wv.read(sect_ckpt)
                        mastered_parts.append(_pcm)
                        # Get report from checkpoint if available
                        continue
                    except Exception:
                        sections_done.discard(idx)  # re-do if load fails
            pct = 10 + int(70 * idx / len(section_files))
            prog(pct, f"Mastering section {idx+1}/{len(section_files)}…")
            pcm16, report = master_chunked(sf, masterfx, chain, mopts,
                                          lambda p, m: prog(pct, m), SR)
            last_report = report
            # Save to disk for crash recovery
            if sect_ckpt:
                try:
                    import scipy.io.wavfile as _wv
                    _wv.write(sect_ckpt, SR, pcm16)
                    sections_done.add(idx)
                    _save_ckpt(len(section_files), sections_done, "mastering")
                except Exception:
                    pass
            mastered_parts.append(pcm16)
            import gc
            gc.collect()

        # Stitch with 2s crossfades.
        # master_chunked returns int16; convert to float [-1, 1] for the
        # crossfade math, then back to int16. (Float WAV values must be
        # in [-1, 1] — int16-scale floats would clip catastrophically.)
        prog(85, "Stitching sections…")
        if len(mastered_parts) == 1:
            result = mastered_parts[0]
        else:
            # Ensure all are 2D float in [-1, 1]
            parts = []
            for p in mastered_parts:
                if p.ndim == 1:
                    p = p[:, None]
                if p.dtype == np.int16:
                    p = p.astype(np.float32) / 32768.0
                elif p.dtype != np.float32:
                    p = p.astype(np.float32)
                parts.append(p)

            result = parts[0]
            for nxt in parts[1:]:
                # Crossfade: overlap last 2s of result with first 2s of nxt
                if len(result) >= xfade_n and len(nxt) >= xfade_n:
                    fade_out = np.linspace(1, 0, xfade_n, dtype=np.float32)[:, None]
                    fade_in = np.linspace(0, 1, xfade_n, dtype=np.float32)[:, None]
                    # Ensure channel match
                    if result.shape[1] != nxt.shape[1]:
                        if nxt.shape[1] == 1:
                            nxt = np.repeat(nxt, result.shape[1], axis=1)
                        else:
                            result = np.repeat(result, nxt.shape[1], axis=1)
                    tail = result[-xfade_n:] * fade_out
                    head = nxt[:xfade_n] * fade_in
                    xfade = tail + head
                    result = np.concatenate([result[:-xfade_n], xfade, nxt[xfade_n:]], axis=0)
                else:
                    result = np.concatenate([result, nxt], axis=0)
                del nxt
                import gc
                gc.collect()
            # Back to int16 for the WAV writer
            result = np.clip(result, -1.0, 1.0)
            result = (result * 32767).astype(np.int16)

        return result, last_report
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)
